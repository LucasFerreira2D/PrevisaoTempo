package br.com.trabalhofinal.data.model;

public class WeatherResponse {
    public String by;
    public boolean valid_key;
    public Results results;
    public double execution_time;
    public boolean from_cache;
}


